# Module B – Mock Exams

This module contains timed Coderbyte-style DevOps mock assignments.

- `exam_01` – Web service + Docker + Terraform + K8s
- `exam_02` – Log pipeline + S3 + CI pipeline

Run via root Makefile or the interactive menu.
