# Module E – Custom Plan for Specific Job

Use this module to tailor your preparation to a specific job description.

1. Paste job description into `job_description.md`.
2. Fill out `skills_mapping.md` to map requirements to this repo.
3. Track progress in `checklist.md`.
