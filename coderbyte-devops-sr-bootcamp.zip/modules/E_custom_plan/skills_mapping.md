# Skills Mapping

Example:

- Python scripting -> Module A (python-basics/*)
- Bash/Linux -> Module A (bash-basics/*)
- Docker -> Module C, Module D (dockerfile_fix)
- Terraform -> Module C, D (terraform_bucket), B exams
- Kubernetes -> Module C, D (k8s_deployment), B exams
